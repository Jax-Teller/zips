plugin.image.bancadejornais
===========================

Addon XBMC/Kodi para a banca sapo
